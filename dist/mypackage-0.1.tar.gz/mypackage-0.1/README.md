# mypackage
this library was created as an example